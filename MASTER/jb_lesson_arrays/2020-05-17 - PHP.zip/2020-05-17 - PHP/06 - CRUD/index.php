<?php

// Connect to database: 
$connection = mysqli_connect("localhost", "root", "", "northwind");
if(mysqli_connect_errno($connection)) {
    $msg = "Error: " . mysqli_connect_error();
    die($msg);
}

//// Add new employee: 
$sql = "INSERT INTO Employees(FirstName, LastName) VALUES('Moishe','Ufnik')";
mysqli_query($connection, $sql);
$newId = mysqli_insert_id($connection);
echo "A new employee has been added. ID: $newId.<br>";

// Update that employee - change lastname, city, country
$sql = "UPDATE Employees SET LastName='Ufnik the King', City='Tel Aviv', Country='Israel' WHERE EmployeeID=$newId";
mysqli_query($connection, $sql);
$affectedRows = mysqli_affected_rows($connection);
echo "An existing employee has been updated. Affected Rows: $affectedRows.<br>";

// Delete that employee: 
$sql = "DELETE FROM Employees WHERE EmployeeID=$newId";
mysqli_query($connection, $sql);
$affectedRows = mysqli_affected_rows($connection);
echo "An existing employee has been deleted. Affected Rows: $affectedRows.<br>";

// Select table: 
$sql = "SELECT EmployeeID as id, FirstName as fName, LastName as lName FROM Employees";
$table = mysqli_query($connection, $sql);
$emp = mysqli_fetch_object($table);
while($emp) {
    $employees[] = $emp;
    $emp = mysqli_fetch_object($table);
}
$json = json_encode($employees);
echo $json;

// Close connection: 
mysqli_close($connection);

