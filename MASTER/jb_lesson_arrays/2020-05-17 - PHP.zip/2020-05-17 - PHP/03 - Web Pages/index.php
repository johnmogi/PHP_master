<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <h1>This is our header...</h1>
        
        <?php
            echo "<h3>Cool Site!</h3>";
        ?>
        
        <p>Some paragraph...</p>
        
        <?php
            $a = 10;
            $b = 20;
            echo $a + $b;
        ?>
    
        <h4>All rights reserved...</h4>
        
    </body>
    
</html>
