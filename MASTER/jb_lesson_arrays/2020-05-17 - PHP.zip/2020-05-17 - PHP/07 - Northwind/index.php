<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <h1>Add Product: </h1>
        
        <form action="products-controller.php" method="post">
            
            <input type="text" placeholder="Name..." name="name">
            <br><br>
            
            <input type="number" placeholder="Price..." name="price">
            <br><br>
            
            <input type="number" placeholder="Stock..." name="stock">
            <br><br>
            
            <input type="hidden" name="command" value="addProduct">
            
            <button>Add Product</button>
        </form>
    </body>
</html>
