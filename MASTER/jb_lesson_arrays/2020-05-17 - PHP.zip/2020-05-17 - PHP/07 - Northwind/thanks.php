<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="3; URL='index.php'" />
        <title></title>
    </head>
    <body>
        <h1>Done.</h1>
    </body>
</html>
