<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="save.php" method="post">

            <input type="text" placeholder="First name..." name="firstName" />
            <br><br>
            
            <input type="text" placeholder="Last name..." name="lastName" />
            <br><br>
            
            <button>Save</button>
            
        </form>
    </body>
</html>
