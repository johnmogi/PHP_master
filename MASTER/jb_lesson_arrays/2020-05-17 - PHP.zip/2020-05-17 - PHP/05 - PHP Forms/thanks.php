<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="3; URL='index.php'" /> 
        <title>Thanks</title>
    </head>
    <body>
        <h3>Your data has been successfully saved.</h3>
    </body>
</html>
