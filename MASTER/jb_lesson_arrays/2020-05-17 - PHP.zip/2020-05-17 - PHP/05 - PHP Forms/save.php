<?php

$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];

// Saving that data to the database...

// echo "First name: $firstName, Last name: $lastName";
header("location: thanks.php");


