<?php

require_once './primes.php';

$primes = getPrimes(1000);

for($i = 0; $i < count($primes); $i++) {
    echo $primes[$i] . ", ";
}



