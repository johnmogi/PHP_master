<?php

function getPrimes($count) {
    $primes = [];
    
    for($i = 1; $i <= $count; $i++) {
        if(isPrime($i)) {
            $primes[] = $i;
        }
    }
    
    return $primes;
}

function isPrime($n) {
    
    $n = abs($n);
    
    if($n == 1) {
        return false;
    }
    
    $sqrt = sqrt($n);
    for($i = 2; $i <= $sqrt; $i++) {
        if($n % $i == 0) {
            return false;
        }
    }
    
    return true;
}
