<?php

require_once './Cat.php';

class HomeCat extends Cat {
    
    public $food;
    
    public function __construct($name, $age, $food) {
        parent::__construct($name, $age); // super
        $this->food = $food;
    }
    
    public function show() {
        parent::show();
        echo ", Food: $this->food<br>";
    }   
    
    public function makeSound() {
        echo "Meow<br>";
    }

}
