<?php

interface Tester {
    function test();
}
