<?php

// require_once './Cat.php';
require_once './WildCat.php';
require_once './HomeCat.php';
require_once './Tester.php';

$allCats[] = new WildCat("Mitsi", 4, "White");
$allCats[] = new HomeCat("Kitsi", 5, "Mice");
$allCats[] = new WildCat("Pitsi", 6, "Black");
$allCats[] = new HomeCat("Litsi", 7, "Ketly");

foreach($allCats as $cat) {
    $cat->show();
    $cat->makeSound();
    
    if($cat instanceof Tester) {
        $cat->test();
    }
    
    echo "<hr>";
}

 