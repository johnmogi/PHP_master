<?php

require_once './Cat.php';
require_once './Tester.php';

class WildCat extends Cat implements Tester {
    
    public $color;
    
    public function __construct($name, $age, $color) {
        parent::__construct($name, $age); // super
        $this->color = $color;
    }
    
    public function show() {
        parent::show();
        echo ", Color: $this->color<br>";
    }
    
    public function makeSound() {
        echo "Meeeoooooo!<br>";
    }
    
    public function test() {
        echo "Testing this Whild Cat...<br>";
    }
}
