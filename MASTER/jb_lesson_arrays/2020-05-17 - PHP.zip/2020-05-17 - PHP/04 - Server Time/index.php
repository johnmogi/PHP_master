<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Server Time Website</h1>
        
        <?php
            date_default_timezone_set("israel");
            echo "Server Time: " . date("H:i:s") . "<br>";
        ?>
        
        <p>All Rights Reserved &copy;</p>
        
    </body>
</html>
